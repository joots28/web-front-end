(() => {
  const $ = s => document.querySelector(s);
  const scenes = [...document.querySelectorAll('.scene')], N = scenes.length;
  const ink = $('#ink'), dot = $('#dot'), hold = $('#hold');
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const bars = Array.from({ length: 14 }, () => ink.appendChild(document.createElement('i')));
  let cur = 0, busy = false;

  const want = () => Math.min(N - 1, Math.max(0, Math.floor(scrollY / innerHeight + 1e-3)));
  const run = dir => Promise.all(bars.map((b, i) => b.animate(
    dir === 'in'
      ? [{ transform: 'scaleY(0)', transformOrigin: 'top' }, { transform: 'scaleY(1)', transformOrigin: 'top' }]
      : [{ transform: 'scaleY(1)', transformOrigin: 'bottom' }, { transform: 'scaleY(0)', transformOrigin: 'bottom' }],
    { duration: 240, delay: i * 16, fill: 'forwards', easing: 'ease-in-out' }).finished));

  async function sync() {
    if (busy || want() === cur) return;
    busy = true;
    if (!reduce) await run('in');
    scenes[cur].classList.remove('on');
    cur = want();
    scenes[cur].classList.add('on');
    document.body.dataset.s = cur;
    if (!reduce) await run('out');
    busy = false;
    sync();
  }

  addEventListener('scroll', () => {
    document.body.style.setProperty('--t', (scrollY / innerHeight - Math.floor(scrollY / innerHeight)).toFixed(3));
    sync();
  }, { passive: true });

  // cursor
  addEventListener('pointermove', e => { dot.style.left = e.clientX + 'px'; dot.style.top = e.clientY + 'px'; });

  // HOLD: segura para encher o copo; ao completar, avança para a cena final
  let v = 0, holding = false, raf = 0;
  const tick = () => {
    v = Math.max(0, Math.min(1, v + (holding ? 0.012 : -0.02)));
    document.body.style.setProperty('--v', v);
    if (v >= 1) {
      holding = false; v = 0;
      document.body.style.setProperty('--v', 0);
      scrollTo({ top: innerHeight * (N - 1), behavior: reduce ? 'auto' : 'smooth' });
      return (raf = 0);
    }
    raf = v > 0 || holding ? requestAnimationFrame(tick) : 0;
  };
  const press = on => () => { holding = on; if (!raf) raf = requestAnimationFrame(tick); };
  hold.addEventListener('pointerdown', press(true));
  ['pointerup', 'pointerleave', 'pointercancel'].forEach(t => hold.addEventListener(t, press(false)));
  hold.addEventListener('keydown', e => { if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); if (!e.repeat) press(true)(); } });
  hold.addEventListener('keyup', press(false));

  const go = i => scrollTo({ top: innerHeight * i, behavior: reduce ? 'auto' : 'smooth' });
  $('#exp').addEventListener('click', () => go(Math.min(N - 1, cur + 1)));
  $('#again').addEventListener('click', e => { e.preventDefault(); go(0); });
})();
